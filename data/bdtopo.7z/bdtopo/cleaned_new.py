# import fiona
# import pandas as pd

# """
# Clean up address data.
# """
def configure(context):
    context.stage("data.bdtopo.raw", ephemeral = True)
    context.stage("data.spatial.codes")
 
def execute(context):
    print("test")
#     df_ban = context.stage("data.bdtopo.raw")

#     df_ban["commune_id"] = df_ban["commune_id"].astype("category")

#     df_codes = context.stage("data.spatial.codes")
#     requested_communes = set(df_codes["commune_id"].unique())

#     excess_communes = set(df_ban["commune_id"].unique()) - requested_communes
#     if len(excess_communes) > 0:
#         print(excess_communes)
#         print(requested_communes)
#         raise RuntimeError("Excess municipalities in BAN")

#     # Clean up street information
#     # df_ban["street"] = df_ban["raw_street"]
#     # df_ban["street"] = df_ban["street"].str.replace("2 ", "DEUX ")
#     # df_ban["street"] = df_ban["street"].str.replace("4 ", "QUATRE ")
#     # df_ban["street"] = df_ban["street"].str.replace("3 ", "TROIS ")
#     # df_ban["street"] = df_ban["street"].str.replace("-", " ")
#     # df_ban["street"] = df_ban["street"].str.replace("'", " ")
#     # df_ban["street"] = df_ban["street"].str.replace(" ST ", " SAINT ")
#     # df_ban["street"] = df_ban["street"].str.replace(r"^ST ", "SAINT ")
#     # df_ban["street"] = df_ban["street"].str.replace(" STE ", " SAINTE ")
#     # df_ban["street"] = df_ban["street"].str.replace(r"^STE ", "SAINTE ")
#     # df_ban["street"] = df_ban["street"].str.replace(r"^PLACE ", "PL ")

#     # df_ban["number"] = pd.to_numeric(df_ban["raw_number"], errors = "coerce")
#     df_ban = df_ban[["commune_id", "street", "number", "geometry"]]

#     # Filter NaN
#     initial_count = len(df_ban)
#     df_ban = df_ban.dropna()
#     df_ban = df_ban.drop_duplicates(["commune_id", "street", "number"])
#     final_count = len(df_ban)

#     print("Dropping %.2f%% of addresses because of NaN values or duplicates" % (
#         100 * (initial_count - final_count) / initial_count
#     ))

#     context.set_info("initial_count", initial_count)
#     context.set_info("final_count", final_count)

#     return df_ban
